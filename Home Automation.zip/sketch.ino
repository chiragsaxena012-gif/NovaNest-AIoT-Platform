#define BLYNK_TEMPLATE_ID "TMPL3WKRhAkXk"
#define BLYNK_TEMPLATE_NAME "Human Automation"
#define BLYNK_AUTH_TOKEN "3Qcf_7qDiMJae7UfgZcBdbrQDZgjfSl3"

#define BLYNK_PRINT Serial
#define BLYNK_NO_BUILTIN

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
// ================= LCD =================
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ================= WiFi =================
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// ================= Relay Pins =================
#define RELAY1 26   // RED LED
#define RELAY2 27   // GREEN LED
#define RELAY3 14   // PINK LED
#define RELAY4 12   // YELLOW LED

// ================= Button Pins =================
#define BTN1 18
#define BTN2 19
#define BTN3 23
#define BTN4 25

bool r1 = false;
bool r2 = false;
bool r3 = false;
bool r4 = false;

// ================= LCD STATUS =================
void lcdStatus(const char* name, bool state) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Chirag Projects");
  lcd.setCursor(0, 1);
  lcd.print(name);
  lcd.print(": ");
  lcd.print(state ? "OFF" : "ON");
}

// ================= BLYNK =================
BLYNK_WRITE(V0) {
  r1 = param.asInt();
  digitalWrite(RELAY1, r1 ? LOW : HIGH);   // ACTIVE LOW
  lcdStatus("RED LED", r1);
}

BLYNK_WRITE(V1) {
  r2 = param.asInt();
  digitalWrite(RELAY2, r2 ? LOW : HIGH);
  lcdStatus("GREEN LED", r2);
}

BLYNK_WRITE(V2) {
  r3 = param.asInt();
  digitalWrite(RELAY3, r3 ? LOW : HIGH);
  lcdStatus("PINK LED", r3);
}

BLYNK_WRITE(V3) {
  r4 = param.asInt();
  digitalWrite(RELAY4, r4 ? LOW : HIGH);
  lcdStatus("YELLOW LED", r4);
}

// ================= SETUP =================
void setup() {
  Serial.begin(9600);

    Serial.println("====================================");
  Serial.println("     Chirag Innovation Projects     ");
  Serial.println("     ESP32 Human Automation System  ");
  Serial.println("====================================");

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Chirag Projects");
  lcd.setCursor(0, 1);
  lcd.print("System Booting");

  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  pinMode(RELAY3, OUTPUT);
  pinMode(RELAY4, OUTPUT);

  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BTN2, INPUT_PULLUP);
  pinMode(BTN3, INPUT_PULLUP);
  pinMode(BTN4, INPUT_PULLUP);

  // All relays OFF initially
  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);
  digitalWrite(RELAY3, HIGH);
  digitalWrite(RELAY4, HIGH);

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  Blynk.virtualWrite(V0, 0);
  Blynk.virtualWrite(V1, 0);
  Blynk.virtualWrite(V2, 0);
  Blynk.virtualWrite(V3, 0);

  lcd.clear();
  lcd.print("System Ready");
}

// ================= LOOP =================
void loop() {
  Blynk.run();

  if (digitalRead(BTN1) == LOW) {
    delay(300);
    r1 = !r1;
    digitalWrite(RELAY1, r1 ? LOW : HIGH);
    Blynk.virtualWrite(V0, r1);
    lcdStatus("RED LED", r1);
  }

  if (digitalRead(BTN2) == LOW) {
    delay(300);
    r2 = !r2;
    digitalWrite(RELAY2, r2 ? LOW : HIGH);
    Blynk.virtualWrite(V1, r2);
    lcdStatus("GREEN LED", r2);
  }

  if (digitalRead(BTN3) == LOW) {
    delay(300);
    r3 = !r3;
    digitalWrite(RELAY3, r3 ? LOW : HIGH);
    Blynk.virtualWrite(V2, r3);
    lcdStatus("PINK LED", r3);
  }

  if (digitalRead(BTN4) == LOW) {
    delay(300);
    r4 = !r4;
    digitalWrite(RELAY4, r4 ? LOW : HIGH);
    Blynk.virtualWrite(V3, r4);
    lcdStatus("YELLOW LED", r4);
  }
}

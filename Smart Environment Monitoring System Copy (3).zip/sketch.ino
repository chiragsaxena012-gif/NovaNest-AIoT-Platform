#define BLYNK_TEMPLATE_ID "TMPL3wctlgp-5"
#define BLYNK_TEMPLATE_NAME "Smart Environment Monitoring System "
#define BLYNK_AUTH_TOKEN "l8qXC9qDv-uNjTx_IINHWj7RM4z9HvtC"

#include <WiFi.h>
#include <WiFiClient.h>
#include <HTTPClient.h>
#include <BlynkSimpleEsp32.h>
#include <PubSubClient.h>
#include "DHT.h"

// WiFi
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// MQTT
const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

// Favoriot
const char* serverUrl = "https://apiv2.favoriot.com/v2/streams";
const char* deviceID = "Smart_Environment_Monitoring_System@chiragsaxena756";
const char* apiKey = "zbzlI35MVLXgqbUlGOaURFOlNqbUBE5r";

// ----- Pins -----
#define DHTPIN 15
#define DHTTYPE DHT22
#define TRIG_PIN 5
#define ECHO_PIN 18
#define LDR_PIN 19
#define GAS_PIN 21
#define PIR_PIN 23
#define LED_PIN 2

DHT dht(DHTPIN, DHTTYPE);

// LED control from Blynk
BLYNK_WRITE(V6)
{
  int ledState = param.asInt();
  digitalWrite(LED_PIN, ledState);
}

// MQTT callback (for switch control)
void callback(char* topic, byte* payload, unsigned int length) {

  String message;

  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  if (String(topic) == "chirag/led") {

    if (message == "1") {
      digitalWrite(LED_PIN, HIGH);
    }

    if (message == "0") {
      digitalWrite(LED_PIN, LOW);
    }
  }
}

// MQTT reconnect
void reconnectMQTT() {

  while (!client.connected()) {

    Serial.print("Connecting to MQTT...");

    if (client.connect("chirag_mobile")) {

      Serial.println("Connected");

      client.subscribe("chirag/led");   // subscribe for LED control
    }

    else {

      Serial.print("Failed, rc=");
      Serial.print(client.state());

      delay(2000);
    }
  }
}

// Favoriot function
void sendToFavoriot(float temperature, float humidity, float distance, int ldrValue, int gasValue, int pirValue)
{
  if (WiFi.status() == WL_CONNECTED)
  {
    HTTPClient http;

    http.begin(serverUrl);

    http.addHeader("Content-Type", "application/json");

    http.addHeader("apikey", apiKey);

    String data = "{";

    data += "\"device_developer_id\":\"";
    data += deviceID;
    data += "\",";

    data += "\"data\":{";

    data += "\"temperature\":";
    data += temperature;
    data += ",";

    data += "\"humidity\":";
    data += humidity;
    data += ",";

    data += "\"distance\":";
    data += distance;
    data += ",";

    data += "\"ldr\":";
    data += ldrValue;
    data += ",";

    data += "\"gas\":";
    data += gasValue;
    data += ",";

    data += "\"pir\":";
    data += pirValue;

    data += "}}";

    int httpResponseCode = http.POST(data);

    Serial.print("Favoriot Response Code: ");
    Serial.println(httpResponseCode);

    http.end();
  }
}

void setup()
{
  Serial.begin(115200);

  dht.begin();

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);
  pinMode(GAS_PIN, INPUT);
  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  client.setServer(mqtt_server, 1883);

  client.setCallback(callback);

  Serial.println("Chirag Innovation Projects");
  Serial.println("Smart Environment Monitoring System");
  Serial.println("-----------------------------------");
}

void loop()
{
  Blynk.run();

  if (!client.connected()) {
    reconnectMQTT();
  }

  client.loop();

  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (!isnan(temperature) && !isnan(humidity))
  {

    Serial.print("Temperature : ");
    Serial.print(temperature);

    Serial.print(" °C | Humidity : ");
    Serial.print(humidity);
    Serial.println(" %");

    Blynk.virtualWrite(V0, temperature);
    Blynk.virtualWrite(V1, humidity);

    client.publish("chirag/temperature", String(temperature).c_str());
    client.publish("chirag/humidity", String(humidity).c_str());
  }

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH);

  float distance = duration * 0.034 / 2;

  Serial.print("Distance : ");
  Serial.print(distance);
  Serial.println(" cm");

  Blynk.virtualWrite(V2, distance);

  client.publish("chirag/distance", String(distance).c_str());

  int ldrValue = digitalRead(LDR_PIN);

  if (ldrValue == 1)
    Serial.println("LDR : Light Detected");
  else
    Serial.println("LDR : Dark");

  Blynk.virtualWrite(V3, ldrValue);

  client.publish("chirag/ldr", String(ldrValue).c_str());

  int gasValue = digitalRead(GAS_PIN);

  if (gasValue == 0)
    Serial.println("Gas : Detected!");
  else
    Serial.println("Gas : Safe");

  Blynk.virtualWrite(V4, gasValue);

  client.publish("chirag/gas", String(gasValue).c_str());

  int pirValue = digitalRead(PIR_PIN);

  if (pirValue == 1)
  {
    Serial.println("PIR : Motion Detected");
    digitalWrite(LED_PIN, HIGH);
  }
  else
  {
    Serial.println("PIR : No Motion");
    digitalWrite(LED_PIN, LOW);
  }

  Blynk.virtualWrite(V5, pirValue);

  client.publish("chirag/pir", String(pirValue).c_str());

  sendToFavoriot(temperature, humidity, distance, ldrValue, gasValue, pirValue);

  Serial.println("----------------------------");

  delay(2000);
}
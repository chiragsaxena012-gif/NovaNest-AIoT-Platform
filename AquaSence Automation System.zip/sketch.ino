#include <WiFi.h>
#include <HTTPClient.h>
#include <LiquidCrystal.h>

// ===== LCD =====
LiquidCrystal lcd(13, 12, 14, 27, 26, 25);

// ===== WiFi =====
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ===== FAVORIOT =====
const char* serverUrl = "https://apiv2.favoriot.com/v2/streams";
const char* deviceID = "deviceDefault@chiragsaxena756";
const char* apiKey  = "Dc3xOi5MJgDpGuQVerpTVz3Ka7QlQiiC";

// ===== TELEGRAM =====
const char* botToken = "8322253652:AAG32PsG23h08yg8cBAWJHP48PPBl2h8Zvs";
const char* chatID   = "6696403686";

// ===== Pins =====
#define TRIG 5
#define ECHO 18
#define RELAY 23
#define BUZZER 19
#define MODE_PIN 34

long duration;
int distance;
int waterLevel;
String pumpStatus;
String mode = "AUTO";

// ✅ NEW (State Memory)
bool lowLevelSent = false;
bool fullLevelSent = false;

// ===== TELEGRAM FUNCTION =====
void sendTelegramMessage(String message) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    String url = "https://api.telegram.org/bot";
    url += botToken;
    url += "/sendMessage?chat_id=";
    url += chatID;
    url += "&text=" + message;

    http.begin(url);
    http.GET();
    http.end();
  }
}

void setup() {
  Serial.begin(115200);

    Serial.println("----------------------------");
    Serial.println("Chirag Innovation Projects");
  Serial.println("AquaSense Automation System");
  Serial.println("----------------------------");

  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  pinMode(RELAY, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(MODE_PIN, INPUT);

  lcd.begin(16, 2);

lcd.setCursor(0, 0);
lcd.print("Chirag");

lcd.setCursor(0, 1);
lcd.print("Innovation Proj");

delay(3000);
lcd.clear();


  lcd.begin(16, 2);
  lcd.print("Water System");
  delay(2000);
  lcd.clear();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

void loop() {

  // ===== MODE READ =====
  int modeValue = analogRead(MODE_PIN);

  if (modeValue < 2000) {
    mode = "AUTO";
  } else {
    mode = "MANUAL";
  }

  // ===== Ultrasonic =====
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  duration = pulseIn(ECHO, HIGH);
  distance = duration * 0.034 / 2;

  waterLevel = map(distance, 100, 0, 0, 100);
  waterLevel = constrain(waterLevel, 0, 100);

  // ===== AUTO MODE =====
  if (mode == "AUTO") {

    if (waterLevel <= 10) {
      digitalWrite(RELAY, HIGH);
      digitalWrite(BUZZER, HIGH);
      pumpStatus = "ON";

      // ✅ Send only once
      if (!lowLevelSent) {
        sendTelegramMessage("⚠ Water Level Low! Pump Started.");
        lowLevelSent = true;
        fullLevelSent = false;
      }
    } 
    else if (waterLevel >= 80) {
      digitalWrite(RELAY, LOW);
      digitalWrite(BUZZER, LOW);
      pumpStatus = "OFF";

      // ✅ Send only once
      if (!fullLevelSent) {
        sendTelegramMessage("✅ Tank Full! Pump Stopped.");
        fullLevelSent = true;
        lowLevelSent = false;
      }
    }
  }

  // ===== MANUAL MODE =====
  else if (mode == "MANUAL") {
    digitalWrite(RELAY, HIGH);
    digitalWrite(BUZZER, LOW);
    pumpStatus = "MANUAL ON";
  }

  // ===== LCD =====
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("WATER LEVEL:");
  lcd.print(waterLevel);
  lcd.print("%");

  lcd.setCursor(0, 1);
  lcd.print("PUMP:");
  lcd.print(pumpStatus);
  lcd.print(" ");
  lcd.print(mode);

  // ===== FAVORIOT =====
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverUrl);
    http.addHeader("Content-Type", "application/json");
    http.addHeader("apikey", apiKey);

    String payload = "{";
    payload += "\"device_developer_id\":\"" + String(deviceID) + "\",";
    payload += "\"data\":{";
    payload += "\"water_level\":" + String(waterLevel) + ",";
    payload += "\"pump_status\":\"" + pumpStatus + "\",";
    payload += "\"mode\":\"" + mode + "\"";
    payload += "}}";

    http.POST(payload);
    http.end();
  }

  delay(2000);
}

